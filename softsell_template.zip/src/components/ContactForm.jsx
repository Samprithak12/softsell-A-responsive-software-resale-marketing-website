export default function ContactForm() {
  return (
    <section className="py-10 bg-blue-50">
      <h2 className="text-2xl font-bold text-center mb-4">Contact Us</h2>
      <form className="max-w-xl mx-auto bg-white p-6 rounded shadow space-y-4">
        <input className="w-full border p-2 rounded" placeholder="Name" required />
        <input type="email" className="w-full border p-2 rounded" placeholder="Email" required />
        <input className="w-full border p-2 rounded" placeholder="Company" required />
        <select className="w-full border p-2 rounded" required>
          <option value="">Select License Type</option>
          <option>Office 365</option>
          <option>Adobe Suite</option>
        </select>
        <textarea className="w-full border p-2 rounded" placeholder="Message" required />
        <button className="w-full bg-blue-600 text-white py-2 rounded">Submit</button>
      </form>
    </section>
  );
}