export default function Testimonials() {
  const reviews = [
    { name: "Alice", role: "CTO", company: "TechCorp", text: "SoftSell made the process easy and quick." },
    { name: "Bob", role: "IT Manager", company: "Innova", text: "Got great value for our old licenses." },
  ];
  return (
    <section className="py-10 bg-white text-center">
      <h2 className="text-2xl font-bold mb-4">Testimonials</h2>
      <div className="flex flex-col md:flex-row justify-center gap-6">
        {reviews.map((r, i) => (
          <div key={i} className="p-4 bg-gray-100 rounded shadow">
            <p>"{r.text}"</p>
            <p className="mt-2 font-bold">{r.name}, {r.role} @ {r.company}</p>
          </div>
        ))}
      </div>
    </section>
  );
}