export default function WhyChooseUs() {
  const points = [
    { icon: "⚡", title: "Fast Process", desc: "Quick valuation & payments" },
    { icon: "🔒", title: "Secure", desc: "100% data protection" },
    { icon: "📈", title: "Best Price", desc: "Market-leading payouts" },
    { icon: "🧑‍💼", title: "Support", desc: "24/7 live chat assistance" },
  ];
  return (
    <section className="py-10 bg-gray-100 text-center">
      <h2 className="text-2xl font-bold mb-6">Why Choose Us</h2>
      <div className="grid md:grid-cols-4 gap-4">
        {points.map((p, i) => (
          <div key={i} className="p-4 bg-white rounded shadow">
            <div className="text-3xl">{p.icon}</div>
            <h3 className="font-semibold mt-2">{p.title}</h3>
            <p className="text-sm">{p.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}