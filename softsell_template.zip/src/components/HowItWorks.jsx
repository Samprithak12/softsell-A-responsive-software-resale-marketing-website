export default function HowItWorks() {
  const steps = [
    { title: "Upload License", icon: "📤" },
    { title: "Get Valuation", icon: "💰" },
    { title: "Get Paid", icon: "🏦" },
  ];
  return (
    <section className="py-10 bg-white text-center">
      <h2 className="text-2xl font-bold mb-4">How It Works</h2>
      <div className="flex flex-col md:flex-row justify-center gap-8">
        {steps.map((step, i) => (
          <div key={i} className="p-4">
            <div className="text-4xl">{step.icon}</div>
            <h3 className="text-lg mt-2">{step.title}</h3>
          </div>
        ))}
      </div>
    </section>
  );
}