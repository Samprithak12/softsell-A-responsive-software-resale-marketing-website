export default function Hero() {
  return (
    <section className="text-center py-20 bg-blue-100">
      <h1 className="text-4xl font-bold">Sell Unused Software Licenses Easily</h1>
      <p className="text-lg mt-4">Get instant value for your unused licenses</p>
      <button className="mt-6 px-6 py-2 bg-blue-600 text-white rounded-lg">Get a Quote</button>
    </section>
  );
}