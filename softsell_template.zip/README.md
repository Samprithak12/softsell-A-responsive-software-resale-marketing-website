# SoftSell Marketing Website

### Features
- Hero section with CTA
- How it Works (3 steps)
- Why Choose Us (4 points)
- Customer Testimonials
- Contact Form with Validation

### Tech Stack
- React + Vite
- TailwindCSS
- Deployed on Vercel

### Time Spent
~10 minutes
